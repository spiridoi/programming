//
//  Student.hpp
//  Lab 5
//
//  Created by daylin on 25/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#ifndef Student_hpp
#define Student_hpp
#include <string>

#include <stdio.h>

using namespace std;
class Student
{
 public:
    string lastName;
    string firstName;
    
    double mark;
    
    int ID;
    
    Student*next;
    Student ();
    void print();
};




#endif /* Student_hpp */
