//
//  Studentlist.hpp
//  Lab 5
//
//  Created by daylin on 25/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#ifndef Studentlist_hpp
#define Studentlist_hpp

#include <stdio.h>
#include "Student.Hpp"

class StudentList
{
public://protected:
    
    Student* head;
    Student* tail;
    
//public:
    
    Student* curr;
    
    
    StudentList();
    
    void readin();
    void readout();
    
    void sortbysurn();
    void sortbyid();
    void sortbymark();
    
    void add(Student*);
    void destroy();

};




#endif /* Studentlist_hpp */
