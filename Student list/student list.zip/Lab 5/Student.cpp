//
//  Student.cpp
//  Lab 5
//
//  Created by daylin on 25/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#include "Student.hpp"
#include <iostream>

Student::Student()
{
    firstName="";
    lastName="";
    ID=0;
    mark=0;
    next=0;
}

void Student::print()

{
    cout<<lastName<<" "<<firstName<<" "<<ID<<" "<< mark<<endl;
    
}