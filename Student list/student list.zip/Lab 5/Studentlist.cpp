//
//  Studentlist.cpp
//  Lab 5
//
//  Created by daylin on 25/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#include "Studentlist.hpp"
#include "string"
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

StudentList::StudentList()

{
    
    head=tail=curr=NULL;
    
}


void StudentList::readin()
{
    ifstream inFile;
    inFile.open("/Users/user/Desktop/student2015.txt");
    
    //cout<<"student2015.rtf";
    
    if (inFile.fail()) {
        // StudentList
        // cout
        // ifstream
        cout << "unable to open student2015.txt" << endl;
        }
        while (!inFile.eof())
        {
            
            Student* student = new Student();
            inFile >> student->lastName >> student->firstName;
            inFile >> student->ID >> student->mark;
            add(student);
            
            cout<<left<<setw(12)<<student->lastName<<left<<setw(12)<<left<<setw(12)<<student->firstName<<left<<setw(12)<<student->ID<<left<<setw(12)<<student->mark<<endl;
        }
        inFile.close();
}

void StudentList::readout()
{
    ofstream outFile;
    outFile.open("student2015Sorted.txt");
    if (outFile.fail())
        
        {
        cout << "unable to open student2015Sorted.txt" << endl;
        }
    
    curr = head;
    while (curr)
        {
            
            outFile<<left<<setw(12)<< curr->lastName<<left<<setw(12)<<left<<setw(12)<< curr->firstName<<left<<setw(12)<< curr->ID<<left<<setw(12)<< curr->mark<<endl;
            
            curr=curr->next;
            
        }
   
    
    //outFile << "COAKLEY   Thomas      08000010    80" << endl;
    //outFile << "NORTON    Helen       08000059    56";
    outFile.close();
    
    
}


void StudentList::add (Student* _student)

{
    
    //_student->print();
    
    
    // add it to the tail of the list
    if (tail == NULL)
    {
        // list was empty
        head = tail = _student;
    }
    else
    {
        tail->next = _student;
        tail = _student;
    }
    
    
}


void StudentList::sortbysurn()
{
    Student * temphead = head;
    string tempname1;
    string tempname2;
    int tempnum1;
    double tempnum2;
    int counter = 0;
    while (temphead)
    {
        temphead = temphead->next;
        counter++;
    }
    temphead = head;
    
    for (int j=0; j<counter; j++)
    {
        while (temphead->next)
        {
            if (temphead->lastName > temphead->next->lastName)
            {
                tempname1 = temphead->lastName;
                temphead->lastName = temphead->next->lastName;
                temphead->next->lastName = tempname1;
                
                tempname2 = temphead->firstName;
                temphead->firstName = temphead->next->firstName;
                temphead->next->firstName = tempname2;
                
                tempnum1 = temphead->ID;
                temphead->ID = temphead->next->ID;
                temphead->next->ID = tempnum1;
                
                tempnum2 = temphead->mark;
                temphead->mark = temphead->next->mark;
                temphead->next->mark = tempnum2;
                
            }
            else if(temphead->lastName == temphead->next->lastName)
            {
                if (temphead->firstName > temphead->next->firstName)
                {
                    tempname2 = temphead->firstName;
                    temphead->firstName = temphead->next->firstName;
                    temphead->next->firstName = tempname2;
                    
                    tempnum1 = temphead->ID;
                    temphead->ID = temphead->next->ID;
                    temphead->next->ID = tempnum1;
                    
                    tempnum2 = temphead->mark;
                    temphead->mark = temphead->next->mark;
                    temphead->next->mark = tempnum2;
                }
            }
                
            temphead = temphead->next;
        }
        temphead = head;
    }
}




void StudentList::destroy()
{
    Student *Next, *curr = head;
    // iterate until end of the list
    while (curr!=NULL)
    {
        Next = curr->next; // remember the next
        delete curr;       // delete current
        curr = Next;       // move to next
    }
}




