//
//  main.cpp
//  Lab 5
//
//  Created by daylin on 25/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//


//#include "student2015.txt"
#include "StudentList.hpp"
#include "Student.hpp"
#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    
    //cout<< "Please enter the data: "<<endl;
    
    StudentList list_1;
    
    list_1.readin();
    list_1.sortbysurn();
    list_1.readout();
    
    
    list_1.destroy();
    
    return 0;
    
}