//
//  team.hpp
//  Lab 4 Game
//
//  Created by daylin on 04/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#ifndef team_hpp
#define team_hpp

#include <stdio.h>
#include "npc.hpp"
#include "wizzard.hpp"


class team
{
    
 protected:
    
    npc* head;
    npc* tail;
    
 public:
    
    npc* curr;
    int Size;

    
    team();
    
    //void addw(Wizzard* given); not neded because Wizards subclass of npc
    void add(npc *given);
    int size_alive();
    npc * at(int i)const;
    void destroy();

};




#endif /* team_hpp */
