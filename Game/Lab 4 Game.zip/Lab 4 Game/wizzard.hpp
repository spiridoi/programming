//
//  wizzard.hpp
//  Lab 4 Game
//
//  Created by daylin on 12/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#ifndef wizzard_hpp
#define wizzard_hpp

#include <stdio.h>
#include "npc.hpp"

class Wizzard : public npc

{
public:

    virtual void defend(int);
    virtual void print();


};





#endif /* wizzard_hpp */
