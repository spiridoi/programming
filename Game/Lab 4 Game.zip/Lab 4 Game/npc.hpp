//
//  npc.hpp
//  Lab 4 Game
//
//  Created by daylin on 04/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#ifndef npc_hpp
#define npc_hpp

#include <stdio.h>


class npc
{

   public:
    
    //data
    int strenght;
    int skill;
    bool alive;
    npc * next;
    

    
    //constructors
    npc();                               //default constructor
    npc(unsigned int,unsigned int,bool,npc*); //tailor constructor
    
    //methods
    virtual void print();
    virtual int attack();
    virtual void isAlive();
    virtual void defend(int);
    
};

#endif /* npc_hpp */
