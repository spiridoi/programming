//
//  main.cpp
//  Lab 4 Game
//
//  Created by daylin on 04/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#include <iostream>
#include "npc.hpp"
#include "wizzard.hpp"
#include "team.hpp"
#include <string>


using namespace std;


int main() {
    
    
    srand(time(0));
    
    int Size_giv;
    int round;
    int attack;
    string att_play;
    string def_play;
    
    
    cout<< "Enter the size of the teams:"<<endl;
    cin>>Size_giv;
    cout<< "Enter number of rounds:"<<endl;
    cin>>round;
    
    team homeNpc;
    team awayNpc;
    
    Wizzard*wizzh;
    Wizzard*wizza;
    
    int randwizzh =rand()%Size_giv;
    int randwizza =rand()%Size_giv;
    
    
    npc* npch;
    npc* npca;

    
    for(int i=0;i<Size_giv;i++)
        
        {
            //homeNpc.add(i==randwizzh ? wizzh = new Wizzard : npch = new npc);
            //awayNpc.add(i==randwizza ? wizza = new Wizzard : npca = new npc);
            
            wizzh = new Wizzard;
            wizza = new Wizzard;
            npca= new npc;
            npch =  new npc;
            
            if (i==randwizzh)
            {
                //wizzh = new Wizzard;
                homeNpc.add(wizzh);
                //npca= new npc;
                awayNpc.add(npca);
            }
            
            else if (i==randwizza)
            {
                //wizza = new Wizzard;
                awayNpc.add(wizza);
                //npch =  new npc;
                homeNpc.add(npch);

            }
            
            else
            {
                //npch =  new npc;
                homeNpc.add(npch);
                //npca= new npc;
                awayNpc.add(npca);
            }
        }
   
    team* current_T;
    team* A_playing=&homeNpc;
    team* D_playing=&awayNpc;
    
    int randnpc=rand()%Size_giv+1;
    
    npc* current_npcat;
    npc* attacking=homeNpc.at(randnpc);
    npc* defending=awayNpc.at(randnpc);
    
    string current;
    att_play  ="home";
    def_play ="away";
    
    
    {
    
    
        for (int j=1;j<=round;j++)
        {
        
        
        cout<< "----------------\\\\\\----------------"<<endl;
        cout<< "Round: "<<j<<endl;
        cout<< "Player from team "<<att_play<<endl;
        attacking->print();
        cout<<endl<< "Oponent player from team "<<def_play<<":"<<endl;
        defending->print();
        
        attack= attacking->attack();
        defending->defend(attack);
            
        if (!defending->alive)
            j=round;
       
        cout<<endl<< "Size of "<<att_play<<" team(alive players): "<< A_playing->size_alive() <<endl;
        cout<< "Size of "<<def_play<<" team(alive players): "<< D_playing->size_alive() <<endl<<endl;
        
        attacking->print();
            cout<<endl;
        defending->print();
        
        current_T=A_playing;
        A_playing=D_playing;
        D_playing=current_T;
        
        current_npcat=attacking;
        attacking=defending;
        defending=current_npcat;
        
        current = att_play;
        att_play  =def_play;
        def_play =current;
        
        }
    
    }
    
    homeNpc.Size=homeNpc.size_alive();
    awayNpc.Size=awayNpc.size_alive();
    
    
    cout<< "----------------\\\\\\----------------"<<endl<<endl;
    
    if (homeNpc.Size==awayNpc.Size)
        cout<<"            It's a draw"<<endl;
    
    else if(homeNpc.Size>awayNpc.Size)
        cout<<"         Home team wins!!!"<<endl;
    
    else
        cout<<"         Away team wins!!!"<<endl;
    
    cout<<endl<< "----------------\\\\\\----------------"<<endl;
    
    
    homeNpc.destroy();
    awayNpc.destroy();
    
    
    return 0;
}




