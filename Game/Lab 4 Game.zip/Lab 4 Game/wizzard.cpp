//
//  wizzard.cpp
//  Lab 4 Game
//
//  Created by daylin on 12/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#include "wizzard.hpp"
#include <iostream>

using namespace std;


void Wizzard::defend(int att)
{
    srand(time(0));
    int roll = rand()%6+1;
    int def = roll * skill;
    int def_left = att-def;
    if (def_left>0)
        strenght=strenght-def_left;
    else
        strenght=1;
    alive=1;
    
}

void Wizzard::print()
{
    cout<<"Wizzard at play:"<<endl;
    npc::print();
}



