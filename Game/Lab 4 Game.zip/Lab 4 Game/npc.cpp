//
//  npc.cpp
//  Lab 4 Game
//
//  Created by daylin on 04/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#include "npc.hpp"
#include <iostream>
#include <ctime>
using namespace std;


npc::npc()    
{
    strenght=0;
    skill=0;
    alive=0;
    next=0;
}



npc::npc(unsigned int _strenght,unsigned int _skill,bool _alive,npc* _next)
{
    strenght = _strenght;
    skill =_skill;
    alive =_alive;
    next = _next;
}

void npc::print()

{
    cout<<"Strenght: "<<strenght<<endl;
    cout<<"Skill: "<<skill<<endl;
    cout<<"Life: "<<alive<<endl;

}

int npc::attack()
{
    //srand(time(0));
    int roll = rand()%6+1;
    int att = roll*skill;
    return att;
    
}

void npc::isAlive()
{
    if (strenght<=0)
        alive=false;
    else
        alive=true;
}

void npc::defend(int att)
{
    srand(time(0));
    int roll = rand()%6+1;
    int def = roll * skill;
    int def_left = att-def;
    if (def_left>0)
    strenght=strenght-def_left;
    isAlive();
}




