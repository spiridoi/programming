//
//  team.cpp
//  Lab 4 Game
//
//  Created by daylin on 04/11/2015.
//  Copyright © 2015 daylin. All rights reserved.
//

#include "team.hpp"
#include <ctime>
#include <iostream>

team::team()

{
    
    head=tail=curr=0;
    Size=0;
    
}


void team::add(npc*given)
{
    
    
    
        given->strenght=rand()%20+1;
        given->skill=rand()%5+1;
        given->alive=1;
        given->next = NULL;
        given->print();
    
    
        // add it to the tail of the list
    if (tail == NULL)
    {
        // list was empty
        head = tail = given;
    }
    else
    {
        tail->next = given;
        tail = given;
    }
    
    
}


int team::size_alive()
{
    npc * temphead = head;
    
    int counter = 0;
    while (temphead)
    {
        
        if (temphead->strenght>0)
        {
            counter++;
        }
        temphead = temphead->next;
        
    }
    return counter;
}

void team::destroy()
{
    npc *Next, *curr = head;
    // iterate until end of the list
    while (curr!=NULL)
    {
        Next = curr->next; // remember the next
        delete curr;       // delete current
        curr = Next;       // move to next
    }
}



 npc* team:: at(int i)const
{
    npc* ati=0;
    npc* Next=head;
    npc* curr = head;
    
    
    if (i>=1 || i<=Size)
        
    {
        
    // iterate until end of the list
        
        int index=1;
        while (curr)
            
        {
            if(index==i)
                ati=curr;
            Next = curr->next; // remember the next
            curr = Next;// move to next
            index++;
        }
    }
    return ati;
}








