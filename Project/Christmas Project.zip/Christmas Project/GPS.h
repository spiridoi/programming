

#ifndef Christmas_Project_GPS_h
#define Christmas_Project_GPS_h


class GPS

{
public:
    double latitude;
    double longitude;
    
    GPS();
    GPS( double ,double);
    
    void getLocation();
    
};


#endif
