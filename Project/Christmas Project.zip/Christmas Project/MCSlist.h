
#ifndef __Christmas_Project__MCSlist__
#define __Christmas_Project__MCSlist__

#include <iostream>
#include "MCS.h"


// used to create a linked list of MCS objects
class MCSlist

{
public:
    MCS * Next;
    MCS * head;
    MCS * tail;
    MCS * curr;
    MCS * Max;
    
    MCSlist ();
    
    void print();
    double get_average();
    void get_max();
    void sort();
    void add( MCS * _mcs, int _threshold);
    void readIn(int _threshold);
    void readOut();
    void destroy();
};

#endif /* defined(__Christmas_Project__MCSlist__) */
