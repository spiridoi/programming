


#include "Sensor.h"
#include <fstream>
#include<string>
#include<iostream>
#include<iomanip>
using namespace std;

//Default constructor
Sensor::Sensor()
{
    X=0;
    Y=0;
    Z=0;

}
//Taylor constructor
Sensor::Sensor(int _x, int _y, int _z)
{
    X=_x;
    Y=_y;
    Z=_z;
}
// returns x,y,z values of acceleration
void Sensor::readAcceleration()
{
    //return X;
    //return Y;
    //return Z;
            
    cout<<left<<setw(12)<<X<<left<<setw(12)<<Y<<left<<setw(12)<<Z<<endl;
}