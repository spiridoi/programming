

#include "MCS.h"
#include "MCSlist.h"
#include <iomanip>
#include <iostream>
#include <fstream>

using namespace std;
int main()
{
    // The following lines of code demonstrates the working of the getLocation and readAcceleration methods of the GPS and Sensor classes respecivelly
    
    
    MCSlist list_1,list_2;
    GPS testG(53.344384, -6.261056);
    
    Sensor testS(1,5,-3);
    MCS *testM=0;
    
    testG.getLocation();
    testS.readAcceleration();
    
    MCS test(testG, testS , testM);
    
    cout <<endl;
    test.print();
    cout <<endl;
    // Prompts user for the value of the threshold  for the Z axis acceleration
    
    int threshold=0;
    cout<< "Please enter Z-axis acceleration threshold: "<<endl;
    cin >> threshold;
    cout <<endl;
    
    // ReadIn function does the work of emulating taking inputs from the GPS and Accelerometers every second and internally useses the add(_threshold) function to build a linked list of MCS objects that store the gps and acceleration data only if it is above the provided value for the threshold. It also calculates and displays the overall z axis acceleration average( the bumpiness of the road) .
    
    list_1.readIn(threshold);
    
    cout <<endl<<"Average Z-axis acceleration above threshold: "<<left<<setprecision(3)<<list_1.get_average()<<endl;
    cout <<endl;
    
    //finds the element on the linked list with the maximum value of z-axis acceleration
    list_1.get_max();
    
    //displays the data of the element on the linked list with the maximum value of z-axis acceleration
    
    cout << "Maximum Z-axis acceleration above threshold: "<<left<<setprecision(3)<<list_1.Max->dataA.Z<< " at "<<left<<setprecision(9)<< list_1.Max->dataL.latitude<<", "<<left<<setprecision(9)<<list_1.Max->dataL.longitude<<endl;
    cout <<endl;
    
    //sort() functionis used to sort the elements on the list in ascending order of their magnitude of Z axis component of acceleration
    list_1.sort();
    list_1.print();
    
    //List readOut() stores the list_1 to a file for future reference, emulating the device sending data online to the database
    list_1.readOut();
    
    // destroy function used to free up memory space ocupied by the linked list
    list_1.destroy();
    
    
    return 0;
    
}

