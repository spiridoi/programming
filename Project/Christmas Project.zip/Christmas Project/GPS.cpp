
#include "GPS.h"
#include <fstream>
#include<string>
#include<iostream>
#include<iomanip>
using namespace std;

//Default constructor
GPS::GPS()
{
    latitude=0.0;
    longitude=0.0;

}
//Taylor constructor
GPS::GPS( double _Lat,double _Long)
{

    latitude= _Lat;
    longitude=_Long;
}
// returns latitude and longitude values
void GPS::getLocation()
{
    cout<<left<<right<<setprecision(9)<<latitude<<", "<<left<<right<<setprecision(9)<<longitude<<endl;
}
