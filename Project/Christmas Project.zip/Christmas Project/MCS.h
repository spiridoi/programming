

#ifndef __Christmas_Project__MCS__
#define __Christmas_Project__MCS__

#include <iostream>
#include "GPS.h"
#include "Sensor.h"


//Class used to store all the data (acceleration and location)
class MCS
{
public:
    
    GPS dataL;
    Sensor dataA;
    MCS* next;

    MCS ();
    MCS (GPS ,Sensor, MCS*);
    
    void print();

};



#endif /* defined(__Christmas_Project__MCS__) */
