
#include "MCSlist.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <unistd.h>
#include <stdlib.h>
using namespace std;


//default constructor
 MCSlist::MCSlist ()
{
    Next=0;
    head=0;
    tail=0;
    curr=0;
    Max=0;
   
}

//prints out a version of all the MCS object in the order they are stored from the first to the last element of the linked list
void MCSlist::print()
{
    curr = head;
    while (curr)
    {
        cout<<"("<<right<<setprecision(9)<<curr -> dataL.latitude<<", "<<right<<setprecision(9)<< curr->dataL.longitude<<"): "<<right<<setw(3)<<curr-> dataA.Z<<endl;
        
        curr=curr->next;
    }
}

//calculates the average value of the z axis accelerationfor all the elements on the linked list
double MCSlist::get_average()
{
    curr = head;
    double sum=0.0, average = 0.0;
    int count=0;
    while (curr)
    {
        
        sum = sum + abs(curr->dataA.Z);
        curr=curr->next;
        count++;
    }
     average = sum / count;
    return average;
}

//finds the element on the linked list with the maximum value of z-axis acceleration
void MCSlist::get_max()
{
    curr = Max = head;
  
    int max=0, n_max=0;
    max = abs(head->dataA.Z);
    
    while (curr!=tail)
    {
        n_max = abs(curr->next->dataA.Z);
        if ( max < n_max)
        {
            max = n_max;
            Max = curr->next;
        }
        curr=curr->next;
    }
}



// it sorts the linked list on descending order
void MCSlist::sort()
{

    MCS * temphead = head;
    int tempX;
    int tempY;
    int tempZ;
    double templat;
    double templong;
    int counter = 0;
    while (temphead)
    {
        temphead = temphead->next;
        counter++;
    }
    temphead = head;
    
    for (int j=0; j<counter; j++)
    {
        while (temphead->next)
        {
            if (temphead->dataA.Z < temphead->next->dataA.Z)
            {
                templat = temphead->dataL.latitude;
                temphead->dataL.latitude = temphead->next->dataL.latitude;
                temphead->next->dataL.latitude = templat;
                
                templong = temphead->dataL.longitude;
                temphead->dataL.longitude = temphead->next->dataL.longitude;
                temphead->next->dataL.longitude = templong;
                
                tempX = temphead->dataA.X;
                temphead->dataA.X= temphead->next->dataA.X;
                temphead->next->dataA.X = tempX;
                
                tempY = temphead->dataA.Y;
                temphead->dataA.Y = temphead->next->dataA.Y;
                temphead->next->dataA.Y= tempY;
                
                tempZ = temphead->dataA.Z;
                temphead->dataA.Z = temphead->next->dataA.Z;
                temphead->next->dataA.Z= tempZ;
            }
            
            temphead = temphead->next;
        }
        temphead = head;
    }
}
//adds elements to the linked list only if their z vale for the acceleration is bigger than te threshold value
void MCSlist::add( MCS * _mcs, int _threshold)
{
    int x = 0;
    x = sqrt(_mcs->dataA.Z * _mcs->dataA.Z);
    
    if (x > _threshold)
        
    {
        if (tail == NULL) //reached end of list
        {
            head = tail = _mcs; //List is empty
            
        }
        
        else
        {
            tail->next = _mcs;
            tail = _mcs;//update tail
        }
    }
    
}




// reads data from the  GPS.txt and Sensor.txt files and stores it useing add(MCS * _mcs, int _threshold) method

void MCSlist::readIn(int _threshold)

{
    
    
    
    ifstream in;
    
    ifstream in2;
    
    //Open the Gps.txt file
    
    in.open("/Users/user/Desktop/Christmas Project 2/Christmas Project/GPS.txt");
    
    //Open the Sensor.txt file
    
    in2.open("/Users/user/Desktop/Christmas Project 2/Christmas Project/Sensor.txt");
    

    
    
    if (in.fail()) // if gps txt file wont open print warning message
        
        cout << "unable to open GPS.txt" << endl;
    
    if (in2.fail()) //if sensor txt file wont open print warning message
    
        cout << "unable to open Sensor.txt" << endl;
    
    
    double sum=0.0, average = 0.0;
    int count=0;
    
    //this condition makes sure that the files are read in symultaneous and each acceleration       data is added to its right location data  as long as an equal number of additional entries are added to both the location and the sensor data.
    while (!in.eof() && !in2.eof())
    {
        
        MCS* mcs = new MCS; //Make new MSC pointer
    
        in>>mcs -> dataL.latitude>>mcs->dataL.longitude;
        in2>>mcs -> dataA.X>>mcs -> dataA.Y>>mcs -> dataA.Z;
        
        sum = sum + abs( mcs->dataA.Z);
        count++;
        
        mcs->print();
        
        add(mcs,_threshold);
        
        sleep(1);// simulates the data from the sensors being read in once every second
    }
    
    average = sum / count;
    
    cout <<endl;
    cout << "Average Z-axis acceleration is: "<<left<<setprecision(3)<< average<<endl;
    
    in.close();
    in2.close();
}
//opens a new file and stores the elements of the linked list on
void  MCSlist::readOut()
{
    ofstream outFile;
    outFile.open("Dataout.txt");
    if (outFile.fail())
        
    {
        cout << "unable to open student2015Sorted.txt" << endl;
    }
    
    curr = head;
    while (curr)
    {
        
        outFile<<left<<setw(12)<<curr -> dataL.latitude<<left<<setw(12)<< curr->dataL.longitude<<left<<setw(12)<<curr-> dataA.X<<left<<setw(12)<<curr-> dataA.Y<<left<<setw(12)<<curr-> dataA.Z<<endl;
        curr=curr->next;
        
    }
    
    
    outFile << "test on output function" << endl;
    
    outFile.close();
    
    
}

void MCSlist::destroy()
{
    curr = head;
    // iterate until end of the list
    while (curr!=NULL)
    {
        Next = curr->next; // remember the next
        delete curr;       // delete current
        curr = Next;       // move to next
    }

}




