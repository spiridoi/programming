

#ifndef Christmas_Project_Sensor_h
#define Christmas_Project_Sensor_h


class Sensor

{
public:
    int X;
    int Y;
    int Z;
    
    Sensor();
    Sensor(int, int, int);
    
    void readAcceleration();

};





#endif
