

#include "MCS.h"
#include <iostream>
#include <iomanip>
using namespace std;

//Default constructor
MCS::MCS ()
{
    dataL.latitude=0.0;
    dataL.longitude=0.0;
    dataA.X=0;
    dataA.Y=0;
    dataA.Z=0;
    next=0;
    
   
}
//Taylor constructor
MCS::MCS (GPS _loc, Sensor _acc, MCS* _next)
{
    dataL = _loc;
    dataA = _acc;
    next  = _next;
}
//used to output the data stored in each object of class MCS 
void MCS::print()
{
    
     cout<<left<<"("<<right<<setprecision(9)<< dataL.latitude<<", "<<right<<setprecision(9)<< dataL.longitude<<"): "<<right<<setw(3)<<dataA.Z<<endl;

}